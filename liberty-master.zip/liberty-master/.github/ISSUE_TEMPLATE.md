**Is this a BUG REPORT or FEATURE REQUEST?**:
<!-- PUT AN x IN THE BOX -->
- [ ] BUG 
- [ ] FEATURE

**What happened**:

**What did you expect to happen**:

**How to reproduce it (as minimally and precisely as possible)**:


**Anything else we need to know?**:

**Environment**:
- Trudesk Version:
- OS (e.g. from /etc/os-release):
- Node.JS Version:
- MongoDB Version:
- Is this hosted on cloud.trudesk.io:

