'use strict';

module.exports = require('./components/captcha/Captcha');