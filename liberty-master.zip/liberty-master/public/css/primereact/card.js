'use strict';

module.exports = require('./components/card/Card');