'use strict';

module.exports = require('./components/accordion/Accordion');