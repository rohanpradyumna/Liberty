import * as React from 'react';

// tslint:disable-next-line:no-empty-interface
interface BodyRowProps {
}

export class BodyRow extends React.Component<BodyRowProps,any> {}
