import * as React from 'react';

// tslint:disable-next-line:no-empty-interface
interface TableBodyProps {
}

export class TableBody extends React.Component<TableBodyProps,any> {}
