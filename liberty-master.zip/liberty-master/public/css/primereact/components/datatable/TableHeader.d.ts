import * as React from 'react';

// tslint:disable-next-line:no-empty-interface
interface TableHeaderProps {
}

export class TableHeader extends React.Component<TableHeaderProps,any> {}
