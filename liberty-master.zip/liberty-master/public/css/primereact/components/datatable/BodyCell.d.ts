import * as React from 'react';

// tslint:disable-next-line:no-empty-interface
interface BodyCellProps {
}

export class BodyCell extends React.Component<BodyCellProps,any> {}
