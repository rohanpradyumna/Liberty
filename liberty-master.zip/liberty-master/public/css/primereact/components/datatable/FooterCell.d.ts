import * as React from 'react';

// tslint:disable-next-line:no-empty-interface
interface FooterCellProps {
}

export class FooterCell extends React.Component<FooterCellProps,any> {}
