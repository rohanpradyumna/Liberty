import * as React from 'react';

// tslint:disable-next-line:no-empty-interface
interface HeaderCellProps {
}

export class HeaderCell extends React.Component<HeaderCellProps,any> {}
