import * as React from 'react';

// tslint:disable-next-line:no-empty-interface
interface TableFooterProps {
}

export class TableFooter extends React.Component<TableFooterProps,any> {}
