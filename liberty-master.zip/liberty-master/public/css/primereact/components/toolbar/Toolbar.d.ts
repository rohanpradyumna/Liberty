import * as React from 'react';

interface ToolbarProps {
    id?: string;
    style?: object;
    className?: string;
}

export class Toolbar extends React.Component<ToolbarProps,any> {}