import * as React from 'react';

interface ScrollPanelProps {
    id?: string;
    style?: object;
    className?: string;
}

export class ScrollPanel extends React.Component<ScrollPanelProps,any> {}