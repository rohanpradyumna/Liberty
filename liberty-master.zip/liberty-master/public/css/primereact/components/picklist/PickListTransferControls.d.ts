import * as React from 'react';

interface PickListTransferControlsProps {
    source?: any[];
    target?: any[];
    sourceSelection?: any[];
    targetSelection?: any[];
    onTransfer?: any[];
}

export class PickListTransferControls extends React.Component<PickListTransferControlsProps,any> {}
