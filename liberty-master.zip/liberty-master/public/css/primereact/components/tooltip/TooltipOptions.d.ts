export default interface TooltipOptions {
    event?: string;
    position?: string;
    showDelay?: number;
    hideDelay?: number;
}